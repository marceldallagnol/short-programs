import scala.collection.immutable.HashMap
import scala.util.matching.Regex
import Crypt._
import java.io.PrintWriter

case class Entry ( account   : String
                 , password  : String
                 , uid       : Int
                 , gid       : Int
                 , gecos     : String
                 , directory : String
                 , shell     : String
                 )

object Entry {
  
  def apply(line: String) : Entry = {
    val fields = line.split(':')
    new Entry(fields(0),fields(1),Integer.parseInt(fields(2)),Integer.parseInt(fields(3)),fields(4),fields(5),fields(6))
  }

}

object Crack {

  def transformReverse(w: String) : Iterator[String] = {
    Iterator(w,w.reverse)
  }
  
  def transformCapitalize(w: String) : Iterator[String] = {
    if (w == "") { Iterator("") }
    else {
      for (c <- Iterator(w.charAt(0).toLower, w.charAt(0).toUpper); s <- transformCapitalize(w.substring(1)))
        yield (c + s)
    }
  }
  
  def transformDigits(w:String) : Iterator[String] = {
    if (w == "") { Iterator("") }
    else { 
      val c = w.charAt(0)
      val first = c.toLower match {
            case 'o' => Iterator('0',c)
            case 'z' => Iterator('2',c)
            case 'a' => Iterator('4',c)
            case 'b' => Iterator('6','8',c)
            case 'g' => Iterator('9',c)
            case 'q' => Iterator('9',c)
            case 'i' => Iterator('1',c)
            case 'j' => Iterator('1',c)
            case 'e' => Iterator('3',c)
            case 's' => Iterator('5',c)
            case 't' => Iterator('7',c)
            case _   => Iterator(c)
         }
      for (c <- first; s <- transformDigits(w.substring(1)))
        yield (c + s)
    }
  }

  def checkPassword(plain: String, enc: String) : Boolean = 
    Crypt.crypt(enc, plain) == enc
 
  def candidateWords(file: String) =
    Words.wordsMatchingRegexp(file, new Regex("""^.{6,8}$"""))

  // scala> Crack("passwd", "words", "soln.1")
  // goto> scala Crack passwd words soln.1
  def apply(pwdFile: String, wordsFile: String, outFile: String) : Unit = {
    val out = new PrintWriter(outFile)
    var checked = new HashMap[String,Boolean]
    var found = false
    
    for (i <- 1 to 3) {
      val pws = Lines.iterator(pwdFile)
      for (user <- pws if !checked.getOrElse(user,false)) {
        found = false
        val wds = i match {
                     case 1 => Lines.iterator(wordsFile).map(transformReverse(_))
                     case 2 => Lines.iterator(wordsFile).map(transformDigits(_))
                     case 3 => Lines.iterator(wordsFile).map(transformCapitalize(_))
                  }
        val e = Entry(user)
        for (attempt <- wds; tryPass <- attempt if !found) {
          if (checkPassword(tryPass,e.password)) {
            out.println(e.account + "=" + tryPass)
            out.flush
            checked += (user -> true)
            found = true
          }
        }
      }
    }
  }
  
  def main(args: Array[String]) = { 
    println("Begin: Cracking Passwords")
    apply(args(0), args(1), args(2))
    println("Done: Cracking Passwords")
  }
}

// vim: set ts=2 sw=2 et:

