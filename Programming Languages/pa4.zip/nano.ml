exception MLFailure of string

type binop = 
  Plus 
| Minus 
| Mul 
| Div 
| Eq 
| Ne 
| Lt 
| Le 
| And 
| Or          
| Cons

type expr =   
  Const of int 
| True   
| False      
| NilExpr
| Var of string    
| Bin of expr * binop * expr 
| If  of expr * expr * expr
| Let of string * expr * expr 
| App of expr * expr 
| Fun of string * expr    
| Letrec of string * expr * expr
	
type value =  
  Int of int		
| Bool of bool          
| Closure of env * string option * string * expr 
| Nil                    
| Pair of value * value     

and env = (string * value) list

let binopToString op = 
  match op with
      Plus -> "+" 
    | Minus -> "-" 
    | Mul -> "*" 
    | Div -> "/"
    | Eq -> "="
    | Ne -> "!="
    | Lt -> "<"
    | Le -> "<="
    | And -> "&&"
    | Or -> "||"
    | Cons -> "::"

let rec valueToString v = 
  match v with 
    Int i -> 
      Printf.sprintf "%d" i
  | Bool b -> 
      Printf.sprintf "%b" b
  | Closure (evn,fo,x,e) -> 
      let fs = match fo with None -> "Anon" | Some fs -> fs in
      Printf.sprintf "{%s,%s,%s,%s}" (envToString evn) fs x (exprToString e)
  | Pair (v1,v2) -> 
      Printf.sprintf "(%s::%s)" (valueToString v1) (valueToString v2) 
  | Nil -> 
      "[]"

and envToString evn =
  let xs = List.map (fun (x,v) -> Printf.sprintf "%s:%s" x (valueToString v)) evn in
  "["^(String.concat ";" xs)^"]"

and exprToString e =
  match e with
      Const i ->
        Printf.sprintf "%d" i
    | True -> 
        "true" 
    | False -> 
        "false"
    | Var x -> 
        x
    | Bin (e1,op,e2) -> 
        Printf.sprintf "%s %s %s" 
        (exprToString e1) (binopToString op) (exprToString e2)
    | If (e1,e2,e3) -> 
        Printf.sprintf "if %s then %s else %s" 
        (exprToString e1) (exprToString e2) (exprToString e3)
    | Let (x,e1,e2) -> 
        Printf.sprintf "let %s = %s in \n %s" 
        x (exprToString e1) (exprToString e2) 
    | App (e1,e2) -> 
        Printf.sprintf "(%s %s)" (exprToString e1) (exprToString e2)
    | Fun (x,e) -> 
        Printf.sprintf "fun %s -> %s" x (exprToString e) 
    | Letrec (x,e1,e2) -> 
        Printf.sprintf "let rec %s = %s in \n %s" 
        x (exprToString e1) (exprToString e2) 

(*********************** Some helpers you might need ***********************)

let rec fold f base args = 
  match args with [] -> base
    | h::t -> fold f (f(base,h)) t

let listAssoc (k,l) = 
  fold (fun (r,(t,v)) -> if r = None && k=t then Some v else r) None l

(*********************** Your code starts here ****************************)

let lookup (x,evn) = match listAssoc (x,evn) with
                      |Some i -> i
                      |None   -> raise (MLFailure ("Variable not found: " ^ x))

let rec eval (evn,e) = match e with
  |Const i       -> Int i
  |True          -> Bool true
  |False         -> Bool false
  |NilExpr       -> Nil
  |Var x         -> lookup (x,evn)
  |Bin (e1,b,e2) -> let v1 = eval (evn,e1) in
                    let v2 = eval (evn,e2) in
                    (match (v1,b,v2) with
                     |(Int i, Plus, Int j)   -> Int (i + j)
                     |(Int i, Minus, Int j)  -> Int (i - j)
                     |(Int i, Mul, Int j)    -> Int (i * j)
                     |(Int i, Div, Int j)    -> Int (i / j)
                     |(Int i, Eq, Int j)     -> Bool (i = j)
                     |(Int i, Ne, Int j)     -> Bool (i != j)
                     |(Int i, Lt, Int j)     -> Bool (i < j)
                     |(Int i, Le, Int j)     -> Bool (i <= j)
                     |(Int i, Cons, Pair (Int j,v)) -> Pair (Int i,Pair (Int j,v))
                     |(Bool b1, Eq, Bool b2) -> Bool (b1 = b2)
                     |(Bool b1, Ne, Bool b2) -> Bool (b1 != b2)
                     |(Bool b1, And, Bool b2)-> Bool (b1 && b2)
                     |(Bool b1, Or, Bool b2) -> Bool (b1 || b2)
                     |(Bool b1, Cons, Pair (Bool b2,v)) -> Pair (Bool b1,Pair (Bool b2,v))
                     |(v, Cons, Nil)         -> Pair (v,Nil)
                     |_                      -> raise (MLFailure ("Bad types for binary operator."))
                    ) 
  |If (c,e1,e2)    -> (match eval (evn,c) with
                       |Bool true  -> eval (evn,e1)
                       |Bool false -> eval (evn,e2)
                       |_          -> raise (MLFailure ("Non-boolean type in if-clause."))
                      )
  |Let (x,e1,e2)    -> eval ((x,eval (evn,e1))::evn,e2)
  |Letrec (x,e1,e2) -> (match e1 with
                        |Fun (x2,e3) -> eval ((x,Closure(evn,Some x,x2,e3))::evn,e2)
                        |_           -> eval ((x,eval (evn,e1))::evn,e2)
                       )
  |Fun (x,e1)       -> Closure (evn,None,x,e1)
  |App (e1,e2)      -> let v2 = eval (evn,e2) in
                       (match (e1,v2) with
                         |(Var "hd", Pair (x,_)) -> x
                         |(Var "tl", Pair (_,x)) -> x
                         |_  -> let v1 = eval (evn,e1) in
                                (match v1 with
                                  |Closure (evn1,None,x,e3)   -> eval ((x,eval (evn,e2))::evn1,e3)
                                  |Closure (evn1,Some n,x,e3) -> eval ((x,eval (evn,e2))::(n,Closure (evn1,Some n,x,e3))::evn1,e3)
                                  |_                          -> raise (MLFailure ("Non-function variable called as function."))
                                )
                       )


(**********************     Testing Code  ******************************)
